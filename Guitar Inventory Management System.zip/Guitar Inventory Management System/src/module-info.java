module GuitarMiniProject {
}